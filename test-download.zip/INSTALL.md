# Meckano Fill - Installation Instructions

## Quick Setup

1. Extract this zip file to a folder on your computer
2. Open terminal/command prompt in that folder
3. Run: npm install
4. Run: npx playwright install chromium
5. Rename .env.example to .env and add your credentials
6. Run: npm test

## What's Included

- package.json - Project dependencies
- tsconfig.json - TypeScript configuration
- playwright.config.ts - Playwright test configuration
- tests/fill-hours.spec.ts - Main automation script
- src/ - Utility modules (config, logger, time-utils)
- .env.example - Environment variables template
- README.md - Detailed documentation

## Support

If you need help, check the README.md file for detailed instructions and troubleshooting tips.
